import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { DataPackService } from './services/data-pack.service';
import { GlobalsModule } from './globals/globals.module';
import { CheckAdminService } from './services/check-admin.service';
import { AdminsModule } from './admins/admins.module';

@NgModule({
  declarations: [
    AppComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    GlobalsModule,
    HttpClientModule,
    AdminsModule
  ],
  providers: [
    DataPackService,
    CheckAdminService
  ],
  bootstrap: [
    AppComponent
  ]
})
export class AppModule { }
